import json
import numpy as np
rng = np.random.default_rng(2026)
PARAM = dict(building_area=75000.0, cold_zone=57000.0, volume=1400000.0, T_in=-4.0, U=0.4, A_env=80000.0, ACH=0.06, fresh_flow=30.0, occupancy_factor=1.0, snow_count=30.0, snow_hours=8.0, snow_intensity_min=3.0, snow_intensity_mode=3.5, snow_intensity_max=4.0, snow_volume_min=482000.0, snow_volume_mode=550000.0, snow_volume_max=642000.0, aux_intensity=45.0, anchor_MWh_min=36000.0, anchor_MWh_mode=39000.0, anchor_MWh_max=42000.0, EF_base=0.4419, EF_series={2021: 0.4715, 2022: 0.4403, 2023: 0.4419}, service_life=50.0, construction_intensity_min=4.0, construction_intensity_mode=4.5, construction_intensity_max=5.0, refrigerant_charge_kg=4000.0, charge_kg_min=2000.0, charge_kg_max=6000.0, R22_GWP=1810.0, leakage_min=0.01, leakage_mode=0.03, leakage_max=0.05, COP_min=2.5, COP_mode=3.0, COP_max=4.0, U_floor=0.25, A_floor=57000.0, ground_T=22.0)
EF_MAT = dict(concrete_C30_t_m3=0.295, concrete_C50_t_m3=0.385, steel_t_t=2.365, glass_t_t=1.13)
MAT_Q = dict(concrete_m3=25000.0, concrete_C50_share=0.3, steel_t=10300.0, glass_t=500.0)
EOL_RATIO = dict(demolition=0.08, recycling=-0.2)
DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
GZ_T = [14, 15, 18, 22, 26, 29, 30, 30, 28, 24, 19, 15]
GZ_W = [0.006, 0.008, 0.012, 0.016, 0.019, 0.021, 0.022, 0.022, 0.02, 0.016, 0.011, 0.007]
HARBIN_T = [-17, -13, -3, 7, 15, 21, 23, 21, 14, 5, -6, -14]
HARBIN_W = [0.002, 0.002, 0.003, 0.005, 0.008, 0.012, 0.015, 0.014, 0.01, 0.006, 0.003, 0.002]
W_IN = 0.002
RHO, CP, H_FG = (1.2, 1.005, 2500.0)

def _dh_degree_hours(T, T_in):
    return sum(((T[m] - T_in) * DAYS[m] * 24.0 for m in range(12)))

def operational_mwh(p, T, W, free_cooling=True):
    q_env = 0.0
    q_inf = 0.0
    q_lat = 0.0
    q_floor = 0.0
    fresh = p['fresh_flow'] * p['occupancy_factor']
    cop = p.get('COP_mode', 3.0)
    for m in range(12):
        dt = T[m] - p['T_in']
        dt_mech = 0.0 if free_cooling and dt < 0 else dt
        q_env += p['U'] * p['A_env'] * dt_mech * DAYS[m] * 24.0 / 1000000.0
        q_inf += RHO * p['volume'] * p['ACH'] * CP * dt_mech * DAYS[m] * 24.0 / 3600000.0
        q_floor += p['U_floor'] * p['A_floor'] * (p['ground_T'] - p['T_in']) * DAYS[m] * 24.0 / 1000000.0
        mass = RHO * fresh * DAYS[m] * 86400.0
        q_lat += mass * max(W[m] - W_IN, 0.0) * H_FG / 3600000.0
    e_env = q_env / cop
    e_inf = q_inf / cop
    e_floor = q_floor / cop
    e_dehum = q_lat / cop
    vol_scale = p['snow_count'] / 30.0
    int_scale = p['snow_hours'] / 8.0
    v_s = p['snow_volume_mode'] * vol_scale
    e_s = p['snow_intensity_mode'] * int_scale
    q_snow = e_s * v_s / 1000.0
    q_aux = p['building_area'] * p['aux_intensity'] / 1000.0
    total = e_env + e_inf + e_floor + e_dehum + q_snow + q_aux
    return dict(env=e_env, inf=e_inf, floor=e_floor, dehum=e_dehum, snow=q_snow, aux=q_aux, total=total)

def material_carbon(mat_q, ef, p):
    c30 = mat_q['concrete_m3'] * (1 - mat_q['concrete_C50_share']) * ef['concrete_C30_t_m3']
    c50 = mat_q['concrete_m3'] * mat_q['concrete_C50_share'] * ef['concrete_C50_t_m3']
    st = mat_q['steel_t'] * ef['steel_t_t']
    gl = mat_q['glass_t'] * ef['glass_t_t']
    c_con = p['building_area'] * p['construction_intensity_mode'] / 1000.0
    return c30 + c50 + st + gl + c_con

def eol_carbon(mat_c, ratio):
    return mat_c * (ratio['demolition'] + ratio['recycling'])

def baseline(p, T, W, mat_q, ef_mat, eol_r):
    dis = operational_mwh(p, T, W)
    shares = {k: v / dis['total'] for k, v in dis.items()}
    anchor = p['anchor_MWh_mode']
    c_op = anchor * p['EF_base']
    leak = p['leakage_mode']
    c_ref = p['refrigerant_charge_kg'] * leak * p['R22_GWP'] / 1000.0
    c_op_total = c_op + c_ref
    mat_c = material_carbon(mat_q, ef_mat, p)
    eol_c = eol_carbon(mat_c, eol_r)
    c_mat_yr = mat_c / p['service_life']
    c_eol_yr = eol_c / p['service_life']
    c_total = c_op_total + c_mat_yr + c_eol_yr
    return dict(dis=dis, shares=shares, anchor=anchor, c_op=c_op, c_ref=c_ref, c_op_total=c_op_total, mat_c=mat_c, c_mat_yr=c_mat_yr, eol_c=eol_c, c_eol_yr=c_eol_yr, c_total=c_total)

def sample_tri(low, mode, high, size):
    return rng.triangular(low, mode, high, size)

def sample_snow_intensity(p, size):
    return rng.triangular(p['snow_intensity_min'], p['snow_intensity_mode'], p['snow_intensity_max'], size)

def sample_snow_volume(p, size):
    return rng.triangular(p['snow_volume_min'], p['snow_volume_mode'], p['snow_volume_max'], size)

def sample_ef_series(p, size):
    vals = np.array(list(p['EF_series'].values()), dtype=float)
    idx = rng.integers(0, len(vals), size)
    return vals[idx]

def ef_series_stats(p):
    vals = np.array(list(p['EF_series'].values()), dtype=float)
    return dict(mean=float(vals.mean()), sd=float(vals.std(ddof=1)), low=float(vals.min()), high=float(vals.max()))

def monte_carlo(p, ef_mat, mat_q, eol_r, n=10000):
    a = sample_tri(p['anchor_MWh_min'], p['anchor_MWh_mode'], p['anchor_MWh_max'], n)
    ef = sample_ef_series(p, n)
    leak = sample_tri(p['leakage_min'], p['leakage_mode'], p['leakage_max'], n)
    cm = mat_q['concrete_m3'] * rng.triangular(0.8, 1.0, 1.2, n)
    st = mat_q['steel_t'] * rng.triangular(0.8, 1.0, 1.2, n)
    gl = mat_q['glass_t'] * rng.triangular(0.8, 1.0, 1.2, n)
    c30 = cm * (1 - mat_q['concrete_C50_share']) * ef_mat['concrete_C30_t_m3']
    c50 = cm * mat_q['concrete_C50_share'] * ef_mat['concrete_C50_t_m3']
    c_con = p['building_area'] * rng.triangular(p['construction_intensity_min'], p['construction_intensity_mode'], p['construction_intensity_max'], n) / 1000.0
    mat_c = c30 + c50 + st * ef_mat['steel_t_t'] + gl * ef_mat['glass_t_t'] + c_con
    c_mat_yr = mat_c / p['service_life']
    c_eol_yr = c_mat_yr * (eol_r['demolition'] + eol_r['recycling'])
    c_op = a * ef
    ch = sample_tri(p['charge_kg_min'], p['refrigerant_charge_kg'], p['charge_kg_max'], n)
    c_ref = ch * leak * p['R22_GWP'] / 1000.0
    c_total = c_op + c_ref + c_mat_yr + c_eol_yr
    snow_mwh = sample_snow_intensity(p, n) * sample_snow_volume(p, n) / 1000.0
    return dict(total=c_total, op=c_op + c_ref, mat=c_mat_yr, eol=c_eol_yr, snow_mwh=snow_mwh)

def ci_90(x):
    return (np.percentile(x, 5), np.percentile(x, 95))

def op_carbon_of_factors(X, p, T, W):
    out = []
    for row in X:
        pp = dict(p)
        pp['U'] = row[0]
        pp['ACH'] = row[1]
        pp['fresh_flow'] = row[2]
        pp['snow_count'] = row[3]
        pp['snow_hours'] = row[4]
        pp['occupancy_factor'] = row[5]
        pp['COP_mode'] = row[6]
        dis = operational_mwh(pp, T, W)
        out.append(dis['total'] * row[7])
    return np.array(out)

def sobol_analysis(p, T, W, n=256):
    from SALib.sample import sobol as sobol_sample
    from SALib.analyze import sobol
    problem = {'num_vars': 8, 'names': ['U', 'ACH', 'fresh_flow', 'snow_count', 'snow_hours', 'occupancy', 'COP', 'EF'], 'bounds': [[0.2, 0.6], [0.02, 0.15], [15, 50], [13, 55], [2, 16], [0.5, 1.5], [2.5, 4.0], [0.4403, 0.4715]]}
    X = sobol_sample.sample(problem, n, seed=2026)
    Y = op_carbon_of_factors(X, p, T, W)
    Si = sobol.analyze(problem, Y)
    return (problem['names'], Si['S1'], Si['ST'], Si['S1_conf'], Si['ST_conf'])

def free_cooling_metrics(p, T):
    hours = 0.0
    dd = 0.0
    for m in range(12):
        if T[m] < p['T_in']:
            hours += DAYS[m] * 24.0
            dd += (p['T_in'] - T[m]) * DAYS[m] * 24.0
    return dict(monthly_mean_free_cooling_potential_hours=float(hours), free_cooling_degree_hours=float(dd))

def climate_parametric_sobol(p, n=128, steps=9):
    from SALib.sample import sobol as sobol_sample
    from SALib.analyze import sobol as sobol_analyze
    names = ['U', 'ACH', 'fresh_flow', 'snow_count', 'snow_hours', 'occupancy', 'COP', 'EF']
    bounds = [[0.2, 0.6], [0.02, 0.15], [15, 50], [13, 55], [2, 16], [0.5, 1.5], [2.5, 4.0], [0.4403, 0.4715]]
    problem = {'num_vars': len(names), 'names': names, 'bounds': bounds}
    out = {}
    for i, f in enumerate(np.linspace(0.0, 1.0, steps)):
        T_mix = [HARBIN_T[i_m] + f * (GZ_T[i_m] - HARBIN_T[i_m]) for i_m in range(12)]
        W_mix = [HARBIN_W[i_m] + f * (GZ_W[i_m] - HARBIN_W[i_m]) for i_m in range(12)]
        X = sobol_sample.sample(problem, n, seed=2026 + i)
        Y = op_carbon_of_factors(X, p, T_mix, W_mix)
        Si = sobol_analyze.analyze(problem, Y)
        out[round(float(f), 3)] = dict(free_cooling=free_cooling_metrics(p, T_mix), ST={n: float(Si['ST'][i]) for i, n in enumerate(names)}, S1={n: float(Si['S1'][i]) for i, n in enumerate(names)})
    return out

def plot_climate_response(out, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    xs = sorted(out.keys())
    days = [out[x]['free_cooling']['monthly_mean_free_cooling_potential_hours'] / 24.0 for x in xs]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.2))
    markers = ['o', 's', '^', 'v', 'D', 'P', 'X', '*']
    for i, name in enumerate(['ACH', 'EF', 'fresh_flow', 'occupancy', 'U', 'snow_hours', 'snow_count', 'COP']):
        vals = [out[x]['ST'][name] for x in xs]
        ax1.plot(xs, vals, marker=markers[i], label=name)
    ax1.set_xlabel('Climate gradient: Harbin (0, severe-cold) → Guangzhou (1, hot-summer warm-winter)')
    ax1.set_ylabel('Sobol total-order index (S_Ti)')
    ax1.set_title('I2 · Climate-parametric Sobol: factor importance vs climate')
    ax1.legend(fontsize=8, frameon=False)
    ax1.grid(alpha=0.3)
    ax2.bar([str(round(x, 2)) for x in xs], days, color='#4C72B0')
    ax2.set_xlabel('Climate gradient position')
    ax2.set_ylabel('Free-cooling economizer (days/yr, outdoor < setpoint)')
    ax2.set_title('I3 · Free-cooling potential along the gradient')
    ax2.tick_params(axis='x', labelsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches='tight')
    plt.close(fig)

def shap_analysis(p, T, W, n=5000):
    import xgboost as xgb
    import shap
    from SALib.sample import latin
    names = ['U', 'ACH', 'fresh_flow', 'snow_count', 'snow_hours', 'occupancy', 'COP', 'EF']
    bounds = [[0.2, 0.6], [0.02, 0.15], [15, 50], [13, 55], [2, 16], [0.5, 1.5], [2.5, 4.0], [0.4403, 0.4715]]
    problem = {'num_vars': 8, 'names': names, 'bounds': bounds}
    X = latin.sample(problem, n, seed=2026)
    Y = op_carbon_of_factors(X, p, T, W)
    idx = np.random.default_rng(2026).permutation(n)
    n_tr = int(round(0.8 * n))
    tr, te = (idx[:n_tr], idx[n_tr:])
    X_train, X_test = (X[tr], X[te])
    Y_train, Y_test = (Y[tr], Y[te])
    model = xgb.XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05, n_jobs=-1, random_state=2026)
    model.fit(X_train, Y_train)
    r2 = float(model.score(X_test, Y_test))
    bg = shap.sample(X_train, 100, random_state=2026)
    explainer = shap.TreeExplainer(model, data=bg, feature_perturbation='interventional')
    sv = explainer.shap_values(X_test)
    mean_abs = np.abs(sv).mean(axis=0)
    return (names, mean_abs, X_test, Y_test, model, sv)

def scenario_run(p, T, W, n=10000):
    local = np.random.default_rng(2026)
    a = local.triangular(p['anchor_MWh_min'], p['anchor_MWh_mode'], p['anchor_MWh_max'], n)
    ef_vals = np.array(list(p['EF_series'].values()), dtype=float)
    ef = ef_vals[local.integers(0, len(ef_vals), n)]
    leak = local.triangular(p['leakage_min'], p['leakage_mode'], p['leakage_max'], n)
    ch = p['refrigerant_charge_kg'] * p['R22_GWP'] / 1000.0

    def op_carbon(mod=1.0, ref_mult=1.0, offset_mwh=0.0):
        c_op = np.maximum(a * mod - offset_mwh, 0.0) * ef
        c_ref = ch * leak * ref_mult
        return c_op + c_ref
    m = operational_mwh(p, T, W)
    ref_share = (m['env'] + m['inf']) / m['total']
    s1_energy = 1.0 - ref_share * 0.212
    base = op_carbon(1.0, 1.0, 0.0)
    scen = {'S1 CO2 refrigerant retrofit (R22 direct removed; refrigeration −21.2% [Liu2025])': op_carbon(s1_energy, 0.0, 0.0), 'S2 Condensation heat recovery (preset 3% total-electricity saving)': op_carbon(0.97, 1.0, 0.0), 'S3 Rooftop PV (offset 6.5 GWh/yr)': op_carbon(1.0, 1.0, 6500.0), 'S4 Envelope/air-curtain upgrade (preset 12% total-electricity saving)': op_carbon(0.88, 1.0, 0.0), 'S5 Operational optimisation (preset 5% total-electricity saving)': op_carbon(0.95, 1.0, 0.0), 'Combined': op_carbon(s1_energy * 0.97 * 0.88 * 0.95, 0.0, 6500.0)}
    res = {}
    for k, v in scen.items():
        red = base - v
        res[k] = dict(reduction=float(red.mean()), pct=float(red.mean() / base.mean() * 100), ci=(float(np.percentile(red, 5)), float(np.percentile(red, 95))))
    return (res, float(base.mean()))

def grid_decarbonization(p, T, W, n=300):
    a = sample_tri(p['anchor_MWh_min'], p['anchor_MWh_mode'], p['anchor_MWh_max'], n)
    leak = sample_tri(p['leakage_min'], p['leakage_mode'], p['leakage_max'], n)
    ch = p['refrigerant_charge_kg'] * p['R22_GWP'] / 1000.0
    c_ref = ch * leak
    rate = np.sqrt(p['EF_series'][2023] / p['EF_series'][2021])
    base_ef = p['EF_series'][2023]
    out = {}
    for year, yrs in [(2025, 2), (2030, 7), (2035, 12)]:
        ef_y = base_ef * rate ** yrs
        c = a * ef_y + c_ref
        c0 = a * base_ef + c_ref
        red = c0 - c
        out[year] = dict(EF=float(ef_y), operational_carbon=float(c.mean()), reduction=float(red.mean()), pct=float(red.mean() / c0.mean() * 100))
    return (out, float(rate))

def main():
    base = baseline(PARAM, GZ_T, GZ_W, MAT_Q, EF_MAT, EOL_RATIO)
    mc = monte_carlo(PARAM, EF_MAT, MAT_Q, EOL_RATIO, n=10000)
    for name, arr in [('total', mc['total']), ('op', mc['op']), ('mat', mc['mat']), ('eol', mc['eol'])]:
        lo, hi = ci_90(arr)
    dom = (mc['op'] / mc['total']).mean() * 100
    dis = operational_mwh(PARAM, GZ_T, GZ_W)
    tot = dis['total']
    for k in ['env', 'inf', 'dehum', 'snow', 'aux']:
        pass
    harbin = dict(PARAM, building_area=80000.0, cold_zone=60000.0, T_in=-5.0, ground_T=6.0)
    gz = operational_mwh(PARAM, GZ_T, GZ_W)
    hb = operational_mwh(harbin, HARBIN_T, HARBIN_W)
    for k in ['env', 'inf', 'dehum', 'snow', 'aux']:
        pass
    names, S1, ST, _, _ = sobol_analysis(PARAM, GZ_T, GZ_W, n=2048)
    sobol_rank = np.argsort(-ST)
    for i in sobol_rank:
        pass
    names2, mean_abs, _, _, _, _ = shap_analysis(PARAM, GZ_T, GZ_W, n=5000)
    shap_rank = np.argsort(-mean_abs)
    for i in shap_rank:
        pass
    from scipy.stats import spearmanr
    rho_s, _ = spearmanr(ST, mean_abs)
    scen, base_m = scenario_run(PARAM, GZ_T, GZ_W, n=10000)
    for k, v in scen.items():
        pass
    grid, rate = grid_decarbonization(PARAM, GZ_T, GZ_W, n=300)
    for yr, v in grid.items():
        pass
    clim = climate_parametric_sobol(PARAM, n=512, steps=9)
    fig_path = 'fig_climate_response.png'
    plot_climate_response(clim, fig_path)
    for x in sorted(clim):
        fc = clim[x]['free_cooling']
    for name in ['ACH', 'EF', 'fresh_flow', 'occupancy', 'U', 'snow_hours', 'snow_count', 'COP']:
        seq = [clim[x]['ST'][name] for x in sorted(clim)]
    out = {'baseline': {k: float(v) for k, v in base.items() if not isinstance(v, dict)}, 'disagg_GZ': {k: float(v) for k, v in dis.items()}, 'shares_GZ': {k: float(dis[k] / tot) for k in dis}, 'sobol': {n: {'S1': float(S1[i]), 'ST': float(ST[i])} for i, n in enumerate(names)}, 'shap_mean_abs': {n: float(mean_abs[i]) for i, n in enumerate(names2)}, 'scenarios': {k: {kk: list(vv) if kk == 'ci' else float(vv) for kk, vv in v.items()} for k, v in scen.items()}, 'grid_decarbonization': {str(y): {kk: float(vv) for kk, vv in v.items()} for y, v in grid.items()}, 'ef_series': {'values': {str(y): float(v) for y, v in PARAM['EF_series'].items()}, 'stats': ef_series_stats(PARAM)}, 'mc_total': {'mean': float(mc['total'].mean()), 'sd': float(mc['total'].std()), 'ci90': [float(x) for x in ci_90(mc['total'])]}, 'climate_parametric': {str(x): {'free_cooling': clim[x]['free_cooling'], 'ST': clim[x]['ST']} for x in sorted(clim)}, 'warnings': ['Steel 10,300 t for Guangzhou is officially reported (Saidi supervision); Harbin steel 44,000 t (China Construction Second Bureau 2017); concrete and glass are estimates benchmarked against the Shenyang Wangjiawan ice centre (150,000 m3 underground concrete).', 'Refrigerant charge baseline 4,000 kg; Monte Carlo uses a 2,000-6,000 kg triangular sample (flooded ice rink 1,000-1,200 kg and brine chiller 200-1,950 kg); leakage rate 1-5%.', 'Official energy anchor: Guangzhou Sunac cultural-tourism complex (including snow venue) annual electricity >=200 GWh, load 360 MVA (Huadu Power Supply 2019); the snow venue expenditure-derived 36-42 GWh is consistent.', 'Cold comparator is Harbin Sunac Snow World (indoor snow venue, same type and developer, isolating climate); parameters come from official public data.', 'Cross-climate comparison uses each venue end-use shares (removing scale differences); the two real venues differ in size, setpoint and equipment, so strict climate isolation relies on the virtual-prototype climate gradient.', 'Steel 2.365 and glass 1.130 factors are from the thesis tables; concrete uses the GB/T 51366 per-m3 basis (different bases are not mixed).', 'Operational end-use shares come from the uncalibrated physics model; absolute values follow the anchor.']}
    with open('results.json', 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
if __name__ == '__main__':
    main()