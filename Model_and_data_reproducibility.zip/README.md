# Reproducibility Package

Anonymised materials supporting the study on energy use and life-cycle carbon
emissions of indoor snow venues in the hot-summer warm-winter (HSWW) zone, with a
severe-cold comparator. All author-identifying information has been removed.

## Contents
- code/run_pipeline.py : the author-built energy model (six end uses, expenditure-derived
  anchor, Monte Carlo 10,000, Sobol and XGBoost/SHAP, nine-step climate gradient,
  scenarios and life-cycle outputs).
- data/ : machine-readable result outputs used for the tables and figures.
- weather/ : EPW weather files for the two venues.
- energyplus/ : EnergyPlus model parameters (IDF) and hourly result CSV for six cases.
- figures/ : the eight manuscript figures and the figure source-data workbook.

## Reproduction
1. Python 3 with numpy, pandas, scipy, SALib, xgboost, shap, matplotlib, openpyxl.
2. From code/, run `python run_pipeline.py`; the deterministic outputs match the JSON
   files in data/.
3. The IDF files in energyplus/ can be opened and re-run independently in EnergyPlus 25.1
   with the weather files provided.

## Scope notes
The EnergyPlus verification covers envelope, infiltration and latent loads; its floor
is adiabatic and internal gains are omitted. The forward energy model retains floor and
internal-load terms. The anchor is expenditure-derived (reported electricity cost divided
by an assumed tariff), not a meter reading. Material quantities for concrete and glass
are estimates and are flagged in the data warnings.
